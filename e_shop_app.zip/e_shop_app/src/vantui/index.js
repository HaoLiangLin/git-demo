import Vue from 'vue'
import {
  Tabbar,
  TabbarItem,
  Search,
  Swipe,
  SwipeItem,
  Image as VanImage,
  Lazyload,
  Grid,
  GridItem,
  TreeSelect,
  NavBar,
  Icon,
  Tab,
  Tabs,
  Button,
  Cell,
  CellGroup,
  Empty,
  GoodsAction,
  GoodsActionIcon,
  GoodsActionButton,
  Checkbox,
  CheckboxGroup
} from 'vant'

Vue.use(Tabbar)
Vue.use(TabbarItem)
Vue.use(Search)
Vue.use(Swipe)
Vue.use(SwipeItem)
Vue.use(VanImage)
Vue.use(Lazyload)
Vue.use(Grid)
Vue.use(GridItem)
Vue.use(TreeSelect)
Vue.use(NavBar)
Vue.use(Icon)
Vue.use(Tab)
Vue.use(Tabs)
Vue.use(Button)
Vue.use(Cell)
Vue.use(CellGroup)
Vue.use(Empty)
Vue.use(GoodsAction)
Vue.use(GoodsActionButton)
Vue.use(GoodsActionIcon)
Vue.use(Checkbox)
Vue.use(CheckboxGroup)
