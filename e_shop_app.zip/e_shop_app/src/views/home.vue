<template>
  <div>
    <Search />
    <Swipe />
    <Menu />
    <div v-for="item in special" :key="item.id">
      <Special :title="item.titel" :lists="item.lists"></Special>
    </div>
  </div>
</template>

<script>
import Search from '@/components/home/search.vue'
import Swipe from '@/components/home/swipe.vue'
import Menu from '@/components/home/menu.vue'
import Special from '@/components/home/special.vue'

export default {
  name: 'Home',
  components: {
    Search,
    Swipe,
    Menu,
    Special
  },
  data() {
    return {
      special: []
    }
  },
  methods: {
    setSpecial(value) {
      this.special = value
    }
  },
  created() {
    this.setSpecial(this.$store.state.home.special)
  }
}
</script>

<style lang="less" scoped>
</style>
