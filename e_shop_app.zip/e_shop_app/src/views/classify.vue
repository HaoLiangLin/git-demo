<template>
  <div class="container">
    <Navbar :title="title"></Navbar>
    <van-tree-select :items="items" :active-id.sync="activeId" :main-active-index.sync="activeIndex">
      <template #content>
        <van-grid icon-size="65px">
          <van-grid-item v-for="item in items[activeIndex].children" :key="item.id" :icon="item.url" :text="item.name"></van-grid-item>
        </van-grid>
      </template>
    </van-tree-select>
  </div>
</template>

<script>
import Navbar from '@/components/navbar.vue'
export default {
  name: 'Classify',
  props: ['title'],
  data() {
    return {
      // 左侧选中项的索引
      activeIndex: 0,
      // 右侧选中项的id
      activeId: 0,
      // 分类所需的数据
      items: []
    }
  },
  methods: {
    setItems(value) {
      this.items = value
    }
  },
  created() {
    this.setItems(this.$store.state.classify.items)
  },
  components: {
    Navbar
  }
}
</script>

<style lang="less" scoped>
.container {
  /deep/ .van-tree-select{
    position: relative;
    top: -4px;
  }
}
</style>
