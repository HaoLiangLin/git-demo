<template>
  <div>
    <Head></Head>
    <Menu></Menu>
    <Cell></Cell>
    <Btn></Btn>
  </div>
</template>

<script>
import Head from '@/components/user/head.vue'
import Menu from '@/components/user/menu.vue'
import Cell from '@/components/user/cell.vue'
import Btn from '@/components/user/button.vue'
export default {
  name: 'User',
  components: {
    Head,
    Menu,
    Cell,
    Btn
  }
}
</script>

<style lang="less" scoped>

</style>
