<template>
  <div class="container">
    <van-empty image="error" description="购物车页面正在施工中..." />
    <div class="text" v-if="res">{{res}}</div>
    <van-button type="default" @click="getText">来句话,化解一下尴尬...</van-button>
  </div>
</template>

<script>
import axios from 'axios'
export default {
  name: 'ShoppingCart',
  data() {
    return {
      res: ''
    }
  },
  methods: {
    async getText() {
      const res = await axios.get('https://res.abeim.cn/api-text_sweet')
      this.res = res.data.content
    }
  }
}
</script>

<style lang="less" scoped>
/deep/ .van-button{
  display: block;
  margin: 0 auto;
}
.text{
  text-align: center;
  margin-bottom: 10px;
}
</style>
