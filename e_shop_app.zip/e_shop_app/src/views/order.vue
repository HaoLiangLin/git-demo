<template>
  <div class="container">
    <Navbar :title="title"></Navbar>
    <TabNav :id="id"></TabNav>
  </div>
</template>

<script>
import Navbar from '@/components/navbar.vue'
import TabNav from '@/components/order/tabnav.vue'
export default {
  name: 'Order',
  props: ['id'],
  data() {
    return {
      title: '订单'
    }
  },
  components: {
    Navbar,
    TabNav
  }
}
</script>

<style>

</style>
