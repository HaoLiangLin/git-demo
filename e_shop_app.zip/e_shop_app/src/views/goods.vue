<template>
  <div class="container">
    <Navbar :title="title"></Navbar>
    <Sort :title="title" :goods="goods"></Sort>
  </div>
</template>

<script>
import Navbar from '@/components/navbar.vue'
import Sort from '@/components/goods/sort.vue'
export default {
  name: 'Goods',
  props: ['title'],
  components: {
    Sort,
    Navbar
  },
  data() {
    return {
      goods: []
    }
  },
  methods: {
    setGoods(value) {
      this.goods = value
    },
    getGoods() {

    }
  },
  created() {
    switch (this.title) {
      case '商品列表':
        this.setGoods(this.$store.state.allgoods.goods)
        break
      case '积分商品':
        this.setGoods(this.$store.state.integral.goods)
        break
    }
  }
}
</script>

<style>
</style>
