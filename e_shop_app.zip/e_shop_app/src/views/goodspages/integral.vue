<template>
  <div class="container">
    <Navbar :title="title"></Navbar>
    <Swipe :lists="list.url"></Swipe>
    <DetailCell :lists="list" :id="title"></DetailCell>
    <SpecsCell></SpecsCell>
    <GoodsAction :title="title" />
  </div>
</template>

<script>
import Navbar from '@/components/navbar.vue'
import Swipe from '@/components/goodspages/swipe.vue'
import DetailCell from '@/components/goodspages/detailcell.vue'
import SpecsCell from '@/components/goodspages/specscell.vue'
import GoodsAction from '@/components/goodspages/goodsaction.vue'
export default {
  name: 'GoodsPages-Integral',
  props: ['id'],
  data() {
    return {
      title: '积分商品兑换',
      list: {}
    }
  },
  components: {
    Navbar,
    Swipe,
    DetailCell,
    SpecsCell,
    GoodsAction
  },
  methods: {
    setLists(value) {
      this.list = value
    }
  },
  created() {
    this.setLists(this.$store.state.detailIntegral.banana)
    this.$store.commit('tabstatus/SWITCH', 1)
  }
}
</script>

<style>

</style>
