import Vue from 'vue'
import VueRouter from 'vue-router'
import Home from '@/views/home.vue'
import Goods from '@/views/goods.vue'
import Classify from '@/views/classify.vue'
import User from '@/views/user.vue'
import GoodsPage from '@/views/goodspages/goods.vue'
import IntegralPage from '@/views/goodspages/integral.vue'
import ShoppingCart from '@/views/shoppingcart.vue'
import Order from '@/views/order.vue'
import myWallet from '@/components/user/cell/mywallet.vue'
import Collection from '@/components/user/cell/collection.vue'

Vue.use(VueRouter)

const routes = [
  { path: '/', redirect: '/home' },
  { name: 'home', path: '/home', component: Home },
  { name: 'goods', path: '/goods/:title', component: Goods, props: true },
  { name: 'classify', path: '/classify/:title', component: Classify, props: true },
  { name: 'shoppingcart', path: '/shoppingcart', component: ShoppingCart },
  { name: 'user', path: '/user', component: User },
  { name: 'myWallet', path: '/mywallet', component: myWallet },
  { name: 'collection', path: '/collection', component: Collection },
  { name: 'goodspage', path: '/goodspage/:id', component: GoodsPage, props: true },
  { name: 'integralpage', path: '/integralpage/:id', component: IntegralPage, props: true },
  { name: 'order', path: '/order/:id', component: Order, props: true }
]

const router = new VueRouter({
  routes
})

export default router
