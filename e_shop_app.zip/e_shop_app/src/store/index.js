import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

// 设置总标签栏开关
const tabstatus = {
  namespaced: true,
  state: { status: true },
  mutations: {
    SWITCH(state, value) {
      if (value === 1) {
        state.status = false
      } else if (value === 0) {
        state.status = true
      }
    }
  }
}

// 关于主页的数据
const home = {
  namespaced: true,
  state: {
    // 主页轮播图的数据
    imgList: [
      '/image/轮播图1.jpg',
      '/image/轮播图2.jpg',
      '/image/轮播图3.jpg'
    ],
    // 主页专题的数据
    special: [
      {
        id: 1,
        titel: '限时拼团',
        lists: [
          { id: 1, name: '香蕉', price: 9.9, url: '/image/香蕉.jpg' },
          { id: 2, name: '水蜜桃', price: 10.0, url: '/image/水蜜桃.png' }
        ]
      },
      {
        id: 2,
        titel: '精品推荐',
        lists: [
          { id: 1, name: 'HUAWEI P50', price: 4988.00, url: '/image/HUAWEI P50.png' },
          { id: 2, name: '荣耀 Magic3 Pro', price: 5299.00, url: '/image/荣耀 Magic3 Pro.jpg' }
        ]
      }
    ]
  },
  mutations: {
  },
  actions: {
  },
  modules: {
  }
}

// 关于全部商品的数据
const allgoods = {
  namespaced: true,
  state: {
    goods: [
      { id: 1, name: 'HUAWEI P50', price: 4988.00, url: '/image/HUAWEI P50.png', news: true },
      { id: 2, name: '荣耀 Magic3 Pro', price: 5299.00, url: '/image/荣耀 Magic3 Pro.jpg', news: false },
      { id: 3, name: '香蕉', price: 9.90, url: '/image/香蕉.jpg', news: true },
      { id: 4, name: '水蜜桃', price: 20.00, url: '/image/水蜜桃.png', news: false }
    ]
  },
  mutations: {},
  actions: {}
  // getters: {
  //   priceSort(state) {
  //     function arrStor(a, b) {
  //       return a.price - b.price
  //     }
  //     return state.goods.sort(arrStor)
  //   }
  // }
}

// 关于积分商品的数据
const integral = {
  namespaced: true,
  state: {
    goods: [
      { id: 1, name: '香蕉', price: 10, url: '/image/香蕉.jpg', news: false },
      { id: 2, name: '水蜜桃', price: 20, url: '/image/水蜜桃.png', news: true }
    ]
  },
  mutations: {},
  actions: {}
}

// 关于分类的数据
const classify = {
  namespaced: true,
  state: {
    items: [
      {
        text: '手机',
        children: [
          { id: 1, name: '华为', url: '/image/华为.png' },
          { id: 2, name: '荣耀', url: '/image/荣耀.png' }
        ]
      },
      {
        text: '水果',
        children: [
          { id: 1, name: '苹果', url: '/image/苹果.png' },
          { id: 2, name: '香蕉', url: '/image/香蕉.png' }
        ]
      }
    ]
  },
  mutations: {},
  actions: {}
}

// 各商品的详细数据
const detailGoods = {
  state: {
    banana: {
      id: 3,
      name: '香蕉',
      price: '10.00',
      url: ['/image/香蕉.jpg', '/image/香蕉1.jpg'],
      browse: 31,
      sales: 11,
      text: '新鲜当季水果大芭蕉现摘现卖'
    }
  }
}

// 各积分商品的详细数据
const detailIntegral = {
  state: {
    banana: {
      id: 3,
      name: '香蕉',
      price: '10',
      url: ['/image/香蕉.jpg', '/image/香蕉1.jpg'],
      browse: 29,
      sales: 11,
      text: '新鲜当季水果大芭蕉现摘现卖'
    }
  }
}

// 关于收藏商品列表的数据
const collection = {
  namespaced: true,
  actions: {},
  mutations: {},
  state: {
    lists: [
      {}
    ]
  }
}

export default new Vuex.Store({
  modules: {
    tabstatus,
    home,
    classify,
    allgoods,
    integral,
    detailGoods,
    detailIntegral,
    collection
  }
})
