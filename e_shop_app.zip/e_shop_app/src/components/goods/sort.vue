<template>
  <div class="container">
    <van-tabs v-model="cid" title-active-color="red">
      <van-tab title="综合">
        <List :title="title" :goods="goods"></List>
      </van-tab>
      <van-tab>
        <template #title>
          价格
          <van-icon name="sort" />
        </template>
        <List :title="title"></List>
      </van-tab>
      <van-tab title="新品">
        <List :title="title" :goods="newgoods"></List>
      </van-tab>
    </van-tabs>
  </div>
</template>

<script>
import List from '@/components/goods/list.vue'
export default {
  name: 'Goods-Sort',
  props: ['title', 'goods'],
  data() {
    return {
      cid: 0
    }
  },
  components: {
    List
  },
  computed: {
    // 新品数据
    newgoods() {
      return this.goods.filter(item => item.news)
    }
  }
}
</script>

<style lang="less" scoped>
</style>
