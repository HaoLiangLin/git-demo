<template>
  <div class="container">
    <van-grid  v-if="title == '商品列表'" column-num="2" icon-size="140px" :gutter="10">
      <van-grid-item  v-for="item in goods" :key="item.id" :icon="item.url" :to="{name: 'goodspage', params: {id:item.id}}">
        <template #text>
          <span class="name">{{ item.name }}</span>
          <span class="price">￥{{ item.price }}</span>
        </template>
      </van-grid-item>
    </van-grid>
    <van-grid  v-if="title == '积分商品'" column-num="2" icon-size="140px" :gutter="10">
      <van-grid-item  v-for="item in goods" :key="item.id" :icon="item.url" :to="{name: 'integralpage', params: {id:item.id}}">
        <template #text>
          <span class="name">{{ item.name }}</span>
          <span class="price">{{ item.price }}积分</span>
        </template>
      </van-grid-item>
    </van-grid>
  </div>
</template>

<script>
export default {
  name: 'Goods-List',
  props: ['title', 'goods']
}
</script>

<style lang="less" scoped>
.container {
  margin-top: 10px;

  .name {
    font-size: 12px;
  }

  .price {
    font-size: 16px;
    color: orange;
  }
}
</style>
