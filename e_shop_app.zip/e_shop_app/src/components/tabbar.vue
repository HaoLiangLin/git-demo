<template>
  <div>
    <van-tabbar v-model="active" :route="true" fixed :placeholder="true">
      <van-tabbar-item icon="home-o" :to="{name:'home'}">首页</van-tabbar-item>
      <van-tabbar-item icon="apps-o" :to="{name:'classify', params: {title: '商品分类'}}">分类</van-tabbar-item>
      <van-tabbar-item icon="shopping-cart-o" :to="{name: 'shoppingcart'}">购物车</van-tabbar-item>
      <van-tabbar-item icon="user-o" :to="{name: 'user'}">个人中心</van-tabbar-item>
    </van-tabbar>
  </div>
</template>

<script>
export default {
  name: 'Tabbar',
  data() {
    return {
      active: 0
    }
  }
}
</script>

<style lang="less" scoped>
</style>
