<template>
  <div class="container">
    <van-search v-model="value" placeholder="请输入搜索关键词"></van-search>
  </div>
</template>

<script>
export default {
  name: 'Home-Search',
  data() {
    return {
      value: ''
    }
  }
}
</script>

<style lang="less" scoped>
.container{
  margin-bottom: 5px;
}
</style>
