<template>
  <div class="container">
    <div class="title">{{title}}</div>
    <van-grid icon-size="140px" column-num="2" center>
      <van-grid-item v-for="list in lists" :key="list.id" :icon="list.url" :to="{name: 'goodspage', params: {id:list.id}}">
        <template #text>
          <span class="name">{{ list.name }}</span>
          <span class="price">￥{{ list.price }}</span>
        </template>
      </van-grid-item>
    </van-grid>
  </div>
</template>

<script>
export default {
  name: 'Home-Special',
  props: ['title', 'lists']
}
</script>

<style lang="less" scoped>
.container{
  margin-bottom: 5px;

  .title{
    background-color: #fff;
    padding: 3px;
  }

  .name{
    font-size: 12px;
  }

  .price{
    font-size: 16px;
    color: orange;
  }
}
</style>
