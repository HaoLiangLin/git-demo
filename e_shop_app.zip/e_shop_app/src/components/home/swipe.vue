<template>
  <div class="container">
    <van-swipe class="my-swipe" :autoplay="3000" indicator-color="white">
      <van-swipe-item v-for="(img, index) in imgList" :key="index">
        <img v-lazy="img" width="100%" height="220px">
      </van-swipe-item>
    </van-swipe>
  </div>
</template>

<script>
export default {
  name: 'Home-Swipe',
  data() {
    return {
      imgList: []
    }
  },
  methods: {
    setImgList(value) {
      this.imgList = value
    }
  },
  created() {
    this.setImgList(this.$store.state.home.imgList)
  }
}
</script>

<style lang="less">
.my-swipe .van-swipe-item {
  color: #fff;
  font-size: 20px;
  text-align: center;
}
</style>
