<template>
  <div class="container">
    <van-grid :border="false">
      <van-grid-item icon="shop-o" :to="{name: 'goods', params: {title:'商品列表'}}" text="全部商品"/>
      <van-grid-item icon="award-o" text="优惠券"/>
      <van-grid-item icon="gift-o" :to="{name: 'goods', params: {title:'积分商品'}}" text="积分商品"/>
      <van-grid-item icon="star-o" text="积分签到"/>
    </van-grid>
  </div>
</template>

<script>
export default {
  name: 'Home-Menu'
}
</script>

<style lang="less" scoped>
.container{
  margin-bottom: 5px;
}
</style>
