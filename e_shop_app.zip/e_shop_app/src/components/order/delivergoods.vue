<template>
  <div class="container"></div>
</template>

<script>
export default {
  // 待发货
  name: 'Order-DeliveGoods'
}
</script>

<style>

</style>
