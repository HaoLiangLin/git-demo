<template>
  <div class="container">
    <van-tabs v-model="active">
      <van-tab title="待付款"></van-tab>
      <van-tab title="待发货"></van-tab>
      <van-tab title="待收货"></van-tab>
      <van-tab title="待评价"></van-tab>
      <van-tab title="已完成"></van-tab>
    </van-tabs>
  </div>
</template>

<script>
export default {
  name: 'Order-Tab',
  props: ['id'],
  data() {
    return {
      active: this.id
    }
  }
}
</script>

<style>
</style>
