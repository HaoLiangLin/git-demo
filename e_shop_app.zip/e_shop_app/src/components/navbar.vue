<template>
  <div class="container">
    <van-nav-bar :title="title" left-text="返回" left-arrow @click-left="onClickLeft" :fixed="true" :placeholder="true">
      <template #right>
        <van-icon name="search" size="18" />
      </template>
    </van-nav-bar>
  </div>
</template>

<script>
export default {
  name: 'Navbar',
  props: ['title'],
  methods: {
    onClickLeft() {
      this.$router.back()
      this.$store.commit('tabstatus/SWITCH', 0)
    }
  }
}
</script>

<style>
</style>
