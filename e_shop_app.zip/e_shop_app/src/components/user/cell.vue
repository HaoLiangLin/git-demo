<template>
  <div class="container">
    <van-cell-group>
      <van-cell center title="地址管理" is-link>
        <template #icon>
          <van-icon name="location" color="green"></van-icon>
        </template>
      </van-cell>
      <van-cell center title="我的钱包" is-link :to="{name: 'myWallet'}">
        <template #icon>
          <van-icon name="paid" color="LightCoral"></van-icon>
        </template>
      </van-cell>
      <van-cell center title="我的优惠" is-link>
        <template #icon>
          <van-icon name="coupon" color="Orange"></van-icon>
        </template>
      </van-cell>
      <van-cell center title="我的收藏" is-link :to="{name: 'collection'}" >
        <template #icon>
          <van-icon name="goods-collect" color="Aqua"></van-icon>
        </template>
      </van-cell>
      <van-cell center title="我的足迹" is-link>
        <template #icon>
          <van-icon name="underway" color="Tomato"></van-icon>
        </template>
      </van-cell>
      <van-cell center title="修改密码" is-link>
        <template #icon>
          <van-icon name="setting" color="Chocolate"></van-icon>
        </template>
      </van-cell>
    </van-cell-group>
  </div>
</template>

<script>
export default {
  name: 'User-Cell'
}
</script>

<style lang="less" scoped>
.container{
  margin-bottom: 10px;
}
</style>
