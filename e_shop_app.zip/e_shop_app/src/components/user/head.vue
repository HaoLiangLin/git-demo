<template>
  <div class="head">
    <Setup></Setup>
    <Info></Info>
  </div>
</template>

<script>
import Setup from '@/components/user/head/setup.vue'
import Info from '@/components/user/head/accountInfo.vue'
export default {
  name: 'User-Head',
  components: {
    Setup,
    Info
  }
}
</script>

<style lang="less" scoped>
  .head{
    background-color: red;
    border-radius: 0 0 20px 20px;
    margin: 0 -4px;
    margin-bottom: 20px;
  }
</style>
