<template>
  <div>
    <van-nav-bar :fixed="true" :placeholder="true" :border="false">
      <template #right>
        <van-icon name="setting-o" size="25" color="#fff"></van-icon>
      </template>
    </van-nav-bar>
    <div class="container">
      <div class="head-portrait">
        <van-image round width="100px" height="100px" src="https://img01.yzcdn.cn/vant/cat.jpeg"/>
      </div>
      <div class="nickname">
        <span>用户昵称</span>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'User-Setup'
}
</script>

<style lang="less" scoped>
  /deep/ .van-nav-bar{
    background-color: red;
  }
  .container{
    background-color: red;
    border-radius: 0 0 20px 20px;
    height: 100px;
    line-height: 100px;
    padding: 0 20px;
    padding-bottom: 10px;
    display: flex;
    .head-portrait{
      flex: 1;
    }
    .nickname{
      flex: 2;
      padding-left: 10px;
      color: #fff;
      font-size: 18px;
    }
  }
</style>
