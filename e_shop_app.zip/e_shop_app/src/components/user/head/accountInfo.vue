<template>
  <div class="container">
    <van-grid :border="false">
      <van-grid-item>
        <div class="box">
          <span class="value">5910.1</span><br />
          <span class="title">余额</span>
        </div>
      </van-grid-item>
      <van-grid-item>
        <div class="box">
          <span class="value">1</span><br />
          <span class="title">优惠券</span>
        </div>
      </van-grid-item>
      <van-grid-item>
        <div class="box">
          <span class="value">34</span><br />
          <span class="title">购买数</span>
        </div>
      </van-grid-item>
      <van-grid-item>
        <div class="box">
          <span class="value">801</span><br />
          <span class="title">积分</span>
        </div>
      </van-grid-item>
    </van-grid>
  </div>
</template>

<script>
export default {
  name: 'User-Info'
}
</script>

<style lang="less" scoped>
.container {
  margin: 0 6px;
  height: 60px;
  background-color: rgb(44, 7, 7);
  border-radius: 5px;
  position: relative;
  top: 10px;
  /deep/ .van-grid-item__content {
    background: transparent;
  }
  .box {
    text-align: center;
    position: relative;
    top: -5px;

    &:first-child {
      padding-left: 10px;
    }
    .value {
      display: inline-block;
      color: rgb(216, 20, 20);
    }
    .title {
      display: inline-block;
      color: #fff;
      font-size: 12px;
    }
  }
}
</style>
