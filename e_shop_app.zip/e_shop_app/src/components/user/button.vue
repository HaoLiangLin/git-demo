<template>
  <div>
    <van-button type="danger" block>退 出 登 录</van-button>
  </div>
</template>

<script>
export default {
  name: 'User-Button'
}
</script>

<style lang="less" scoped>
</style>
