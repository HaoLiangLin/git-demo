<template>
  <div class="container">
    <van-grid column-num="5" :border="false">
      <van-grid-item icon="shop-o" text="未支付" :to="{name: 'order', params: {id: 0}}" />
      <van-grid-item icon="logistics" text="待发货" :to="{name: 'order', params: {id: 1}}" />
      <van-grid-item icon="goods-collect-o" text="待收货" :to="{name: 'order', params: {id: 2}}" />
      <van-grid-item icon="cart-o" text="待评价" :to="{name: 'order', params: {id: 3}}" />
      <van-grid-item icon="cart-o" text="已完成" :to="{name: 'order', params: {id: 4}}" />
    </van-grid>
  </div>
</template>

<script>
export default {
  name: 'User-Menu',
  data() {
    return {
      active: 0
    }
  }
}
</script>

<style lang="less" scoped>
.container{
  margin-bottom: 10px;
}
</style>
