<template>
  <div class="container">
    <Navbar :title="title" />
    <Details />
    <Recharge/>
  </div>
</template>

<script>
import Navbar from '@/components/navbar.vue'
import Details from '@/components/user/cell/mywallet/details.vue'
import Recharge from '@/components/user/cell/mywallet/recharge.vue'
export default {
  name: 'User-MyWallet',
  data() {
    return {
      title: '我的钱包'
    }
  },
  components: {
    Navbar,
    Details,
    Recharge
  }
}
</script>

<style>
</style>
