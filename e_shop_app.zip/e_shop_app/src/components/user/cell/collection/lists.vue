<template>
  <div class="container">
    <van-grid :column-num="2">
      <van-grid-item>
        <template #icon>
          <van-checkbox v-model="checked">复选框</van-checkbox>
          <img src="">
        </template>
        <template #text>
          <span>name</span><br/>
          <span>￥price</span>
        </template>
      </van-grid-item>
    </van-grid>
  </div>
</template>

<script>
export default {
  name: 'Colloction-List'
}
</script>

<style lang="less" scoped>

</style>
