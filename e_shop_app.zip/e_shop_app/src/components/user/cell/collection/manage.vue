<template>
  <div class="container">
    <div class="manageNav">
      <span @click="manageBtn" ref="manageBtn">{{content}}</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Collection-Manage',
  data() {
    return {
      status: false,
      content: '管理'
    }
  },
  methods: {
    manageBtn() {
      this.status = !this.status
      if (this.status) {
        this.content = '取消'
        return
      }
      this.content = '管理'
    }
  }
}
</script>

<style lang="less" scoped>
.container {
  .manageNav {
    width: 100%;
    height: 35px;
    line-height: 35px;
    background-color: #fff;

    span {
      display: block;
      float: right;
      margin: 0 15px;
      font-size: 14px;
      color: rgb(117, 117, 117);
    }
  }
}
</style>
