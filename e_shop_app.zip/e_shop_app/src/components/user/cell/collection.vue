<template>
  <div class="container">
    <Navbar :title="title" />
    <Manage/>
  </div>
</template>

<script>
import Navbar from '@/components/navbar.vue'
import Manage from '@/components/user/cell/collection/manage.vue'
export default {
  name: 'User-Collection',
  data() {
    return {
      title: '我的收藏'
    }
  },
  components: {
    Navbar,
    Manage
  }
}
</script>

<style>

</style>
