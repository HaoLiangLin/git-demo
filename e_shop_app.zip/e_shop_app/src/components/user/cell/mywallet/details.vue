<template>
  <div class="container">
    <div>
      <span>总资产(元)</span><br/>
      <span>{{totalAssets}}</span>
    </div>
    <div>
      <span>累计充值(元)</span><br/>
      <span>{{cumulativeRecharge}}</span>
    </div>
    <div>
      <span>累计消费</span><br/>
      <span>{{cumulativeConsume}}</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MyWallet-Details',
  data() {
    return {
      // 总资产
      totalAssets: 5910.1,
      // 累计充值
      cumulativeRecharge: 21241,
      // 累计消费
      cumulativeConsume: 7705
    }
  }
}
</script>

<style lang="less" scoped>
.container{
  width: 100%;
  height: 56px;
  line-height: 28px;
  background-color: #000;
  text-align: center;
  display: flex;
  border-radius: 5px;
  margin: 5px 0 10px;

  div{
    color: orange;
    font-size: 14px;
    flex: 1;
  }
}
</style>
