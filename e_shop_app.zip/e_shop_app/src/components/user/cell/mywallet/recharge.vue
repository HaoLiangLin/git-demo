<template>
  <div class="container">
    <van-cell-group>
      <van-cell title="充值￥100赠送￥10" icon="shop-o">
        <template #default>
          <van-button type="danger" round>充值</van-button>
        </template>
      </van-cell>
      <van-cell title="充值￥1赠送￥1000" icon="shop-o">
        <template #default>
          <van-button type="danger" round>充值</van-button>
        </template>
      </van-cell>
    </van-cell-group>
  </div>
</template>

<script>
export default {
  name: 'MyWalltet-Recharge'
}
</script>

<style lang="less" scoped>
.container{
  /deep/ .van-button{
    height: 24px;
  }
}
</style>
