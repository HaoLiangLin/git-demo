<template>
  <div class="container">
    <van-swipe class="my-swipe" indicator-color="white" @change="onChange">
      <van-swipe-item v-for="(item, index) in lists" :key="index" v-model="current">
        <img v-lazy="item" width="100%" height="300px" />
      </van-swipe-item>
      <template #indicator>
        <div class="custom-indicator">{{ current + 1 }}/{{length}}</div>
      </template>
    </van-swipe>
  </div>
</template>

<script>
export default {
  name: 'GoodsPages-Swipe',
  props: ['lists'],
  data() {
    return {
      current: 0
    }
  },
  methods: {
    onChange(index) {
      this.current = index
    }
  },
  computed: {
    length() {
      return this.lists.length
    }
  }
}
</script>

<style lang="less" scoped>
.container {
  margin: 10px;
  .my-swipe {
    color: #fff;
    font-size: 20px;
    text-align: center;

    img {
      margin: 0 auto;
    }
  }

  .custom-indicator {
    position: absolute;
    right: 5px;
    bottom: 5px;
    padding: 2px 5px;
    font-size: 12px;
    background: rgba(0, 0, 0, 0.1);
  }
}
</style>
