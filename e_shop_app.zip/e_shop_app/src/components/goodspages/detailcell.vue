<template>
  <div class="container">
    <van-cell-group>
      <van-cell :title="price" :label="lists.text" title-style="color: orange;font-size: 24px;" label-class="cell-label">
        <template #default>
          <div class="value">
            <div class="browse">
              <span>{{lists.browse}}</span><br />
              <span>浏览</span>
            </div>
            <div class="sales">
              <span>{{lists.sales}}</span><br />
              <span>销量</span>
            </div>
          </div>
        </template>
      </van-cell>
    </van-cell-group>
  </div>
</template>

<script>
export default {
  name: 'GoodsPages-DetailCell',
  props: ['lists', 'id'],
  computed: {
    price() {
      return this.id === '商品详情' ? '￥' + this.lists.price : this.lists.price + '积分'
    }
  }
}
</script>

<style lang="less" scoped>
.container {
  margin-bottom: 10px;

  .cell-label {
    color: #000;
    padding-top: 5px;
  }

  .value {
    width: 60px;
    display: flex;
    position: absolute;
    right: 0;
    top: 0;

    .invalue {
      flex: 1;
      text-align: center;
      font-size: 12px;
      line-height: 16px;
    }
    .browse {
      .invalue;
    }

    .sales {
      .invalue;
    }
  }
}
</style>
