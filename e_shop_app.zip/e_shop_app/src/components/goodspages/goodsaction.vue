<template>
  <div class="container">
    <van-goods-action safe-area-inset-bottom>
      <van-goods-action-icon icon="shop-o" text="店铺" />
      <van-goods-action-icon icon="star-o" text="收藏" />
      <template v-if="title==='商品详情'">
        <van-goods-action-button type="warning" text="加入购物车" />
        <van-goods-action-button type="danger" text="立即购买" />
      </template>
      <van-goods-action-button v-if="title==='积分商品兑换'" type="danger" text="立即兑换" />
    </van-goods-action>
  </div>
</template>

<script>
export default {
  name: 'GoodsPages-GoodsAction',
  props: ['title']
}
</script>

<style>
</style>
