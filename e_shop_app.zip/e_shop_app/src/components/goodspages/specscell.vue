<template>
  <div class="container">
    <van-cell-group>
      <van-cell title="选择规格:" is-link center></van-cell>
    </van-cell-group>
  </div>
</template>

<script>
export default {
  name: 'GoodsPages-SpecsCell'
}
</script>

<style lang="less" scoped>
.container {
  /deep/ .van-cell-group {
    .van-cell {
      height: 50px;
    }
  }
}
</style>
