<template>
  <div id="app">
    <router-view></router-view>
    <Tabbar v-if="status"></Tabbar>
  </div>
</template>

<script>
import Tabbar from '@/components/tabbar.vue'
export default {
  components: {
    Tabbar
  },
  computed: {
    status() {
      return this.$store.state.tabstatus.status
    }
  }
}
</script>

<style lang="less">
body{
  background-color: #f1f1f1;
  padding: 4px;
  padding-bottom: 0;
}
</style>
