import axios from 'axios'

const request = axios.create({
  // `baseURL` 将自动加在 `url` 前面，除非 `url` 是一个绝对 URL。
  baseURL: '',
  // 如果请求时间超过 `timeout` 的值，则请求会被中断
  timeout: 60000 // 默认值是 `0` (永不超时)
})

export default request
